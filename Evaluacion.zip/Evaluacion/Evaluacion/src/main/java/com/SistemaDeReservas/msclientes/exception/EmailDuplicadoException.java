package com.SistemaDeReservas.msclientes.exception;

/**
 * Excepción lanzada cuando se intenta registrar un email que ya existe en la base de datos.
 */
public class EmailDuplicadoException extends RuntimeException {

    public EmailDuplicadoException(String email) {
        super("Ya existe un cliente registrado con el email: " + email);
    }
}
