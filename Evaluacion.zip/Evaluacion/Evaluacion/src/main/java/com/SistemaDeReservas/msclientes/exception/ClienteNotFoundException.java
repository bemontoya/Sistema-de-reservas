package com.SistemaDeReservas.msclientes.exception;

/**
 * Excepción lanzada cuando no se encuentra un cliente con el ID especificado.
 */
public class ClienteNotFoundException extends RuntimeException {

    public ClienteNotFoundException(Long id) {
        super("No se encontró el cliente con ID: " + id);
    }

    public ClienteNotFoundException(String mensaje) {
        super(mensaje);
    }
}
