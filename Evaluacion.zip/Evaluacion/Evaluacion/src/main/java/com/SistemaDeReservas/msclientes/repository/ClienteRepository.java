package com.SistemaDeReservas.msclientes.repository;

import com.SistemaDeReservas.msclientes.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repositorio JPA para la entidad Cliente.
 * Extiende JpaRepository para obtener operaciones CRUD completas.
 */
@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    // Buscar cliente por email (para validar duplicados)
    Optional<Cliente> findByEmail(String email);

    // Buscar solo clientes activos
    List<Cliente> findByActivoTrue();

    // Verificar si ya existe un email registrado (útil para validaciones)
    boolean existsByEmail(String email);
}
