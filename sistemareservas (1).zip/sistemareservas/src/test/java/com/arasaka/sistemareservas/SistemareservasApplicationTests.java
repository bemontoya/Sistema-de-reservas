package com.arasaka.sistemareservas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemareservasApplicationTests {

	@Test
	void contextLoads() {
	}

}
